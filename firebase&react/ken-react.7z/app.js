var items=[{id:0,name:"gg",openHour:"0000"}];

var SaleBox=React.createClass({
  getInitialState:function(){
    return{items:[]};
  },
  componentWillMount: function() {
    this.firebaseRef = new Firebase("https://blistering-inferno-8099.firebaseio.com/");
    this.firebaseRef.on("child_added", function(dataSnapshot) {
      items.push(dataSnapshot.val());
      this.setState({
        items: items
      });
    }.bind(this));
  },
  render:function(){
    return (
      <SaleList items={this.state.items}/>
    );
  }
});
var SaleList=React.createClass({
  render:function(){
    var saleNodes=this.props.items.map(function(sale){
      return(
        <Sale name={sale.name} key={sale.id}>
          {sale.openHour}
        </Sale>
      );
    });
    return (
      <div className="saleList">
        {saleNodes}
      </div>
    );
  }
});
var Sale=React.createClass({
  rawMarkup: function() {
    var rawMarkup = marked(this.props.children.toString(), {sanitize: true});
    return { __html: rawMarkup };
  },
  render:function(){
    return (
      <div className="sale">
        <h2 className="saleName">
          {this.props.name}
        </h2>
        <span dangerouslySetInnerHTML={this.rawMarkup()} />
      </div>
    );
  }
});
ReactDOM.render(
  <SaleBox items={items} />,
  document.getElementById('content')
);
